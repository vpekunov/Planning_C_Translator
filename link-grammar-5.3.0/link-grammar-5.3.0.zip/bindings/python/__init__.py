#
# __init__.py  file for Link Grammar Python bindings
#
__version__ = "5.3.0"

from .linkgrammar import *
