# Python bindings for Link Grammar

Description
===========
This directory contains a Python interface to the Link Grammar C library.


Testing
=======
See the python-examples directory for unit tests and example usage.
