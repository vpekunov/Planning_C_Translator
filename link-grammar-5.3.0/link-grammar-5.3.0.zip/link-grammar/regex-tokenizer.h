#include "link-includes.h"

int regex_tokenizer_test(Dictionary, const char *);

